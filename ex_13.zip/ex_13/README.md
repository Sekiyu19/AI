# EX_13

## Task
Read Example 7.4 in pp. 152-153 of the textbook,
and try to understand the method for inducing a decision tree.

## Procedure
 - Load the data from the dataset `ionosphere`.
 - Show the tree in text form.
 - Show the tree graphically.

## How to submit your answer
 - Put the matlab program into `prog_13.m`
 - Put the text results into `result.txt`
 - Write some of the production `rules` into `summary_13.txt`.
